Pour d�ployer le site Marmotte:
	d�zipper l'archive
	donner les droits d'�criture au service web dans les dossiers csv, config, uploads
	cr�er un fichier vierge .htpasswd � la racine du site avec droits d'�criture pour le service web
	�diter le fichier config/configDB.inc.php et y renseigner les bonnes valeurs
	
	