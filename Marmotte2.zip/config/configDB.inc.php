<?php
	
	$servername = "127.0.0.1";
	$dbname = "cn6";
	$serverlogin = "cn6";
	$serverpassword = "Dupek33!";
	
	$rootdir = "";
	$tmpdir = "C:/phptmp/";
	
	define("reports_db","reports");
	define("users_db","users");
	define("sessions_db","sessions");
	define("units_db","units");
	define("people_db","people");
	
?>